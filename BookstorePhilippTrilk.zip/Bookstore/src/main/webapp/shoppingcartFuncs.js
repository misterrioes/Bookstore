const url = 'http://localhost:8080/Bookstore/ShoppingCartServlet';

function addToBasket() {
    var quantity = document.getElementById("quantityInput").value;
    var bookId = document.getElementById("bookId").value;

    fetch(url, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/x-www-form-urlencoded'
        },
        body: new URLSearchParams({
            'action': 'putToBasket',
            'bookId': bookId,
            'quantity': quantity,
        })
    }).then(loadshoppingCart)
        .catch(error => {
            throw (error);
        })
}

function updateBasketQuantity(changedQuantityField) {
    var quantity = changedQuantityField.value;
    var bookId = changedQuantityField.id.slice(10);


    fetch(url, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/x-www-form-urlencoded'
        },
        body: new URLSearchParams({
            'action': 'updateBasket',
            'bookId': bookId,
            'quantity': quantity,
        })
    }).then(loadshoppingCart)
        .catch(error => {
            throw (error);
        })
}

function deleteFromBasket(bookId) {


    fetch(url, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/x-www-form-urlencoded'
        },
        body: new URLSearchParams({
            'action': 'deleteFromBasket',
            'bookId': bookId,
        })
    }).then(loadshoppingCart)
        .catch(error => {
            throw (error);
        })
}

function loadshoppingCart() {
    fetch('http://localhost:8080/Bookstore/ShoppingCartServlet').
        then((response) => {
            if (response.ok) {
                var x = response.json();

                return x;
            }
            else if (response.status == 400) {
                var shoppingCartTable = document.getElementById("booksToBuy");
                var parentOfSc = shoppingCartTable.parentElement;
                while (parentOfSc.firstChild) {
                    parentOfSc.removeChild(parentOfSc.firstChild);
                }

                var shoppingCartHeader = document.createElement("h3")
                shoppingCartHeader.innerHTML = "Your shopping Cart"
                var information = document.createElement("p")
                information.innerHTML = "Please go to to the Login Page to see your shopping Cart."
                loginForm = document.createElement("form");
                loginForm.action = "LoginPage.jsp"
                loginForm.innerHTML = "<button type='submit' class= 'btn btn-primary'>Login</button>"
                parentOfSc.appendChild(shoppingCartHeader);
                parentOfSc.appendChild(information);
                parentOfSc.appendChild(loginForm);
                throw new Error("The server has no data for you. Are you logged in?");
            }
            else {
                throw new Error("The server has no data for you. Are you logged in?");
            }
        })

        //.then(response => response.json())
        //.then(response => response.json()) book title, author, cover image (if available), quantity, and total price.
        //if we have the json we want to fill the table with the book data.
        .then((booksToBuy) => {
            var shoppingCartTable = document.getElementById("booksToBuy");
            //clear all children
            while (shoppingCartTable.firstChild) {
                shoppingCartTable.removeChild(shoppingCartTable.firstChild);
            }
            var bookrow = document.createElement("tr");
            var titlheHD = document.createElement("th");
            var authorHD = document.createElement("th");
            var converImageHD = document.createElement("th");
            var quantityHD = document.createElement("th");
            var totalPriceHD = document.createElement("th");
            var deleteHD = document.createElement("th");

            titlheHD.innerHTML = "Title";
            authorHD.innerHTML = "Author";
            converImageHD.innerHTML = "Cover";
            quantityHD.innerHTML = "quantity";
            totalPriceHD.innerHTML = "price";
            deleteHD.innerHTML = "Delete";

            bookrow.appendChild(titlheHD);
            bookrow.appendChild(authorHD);
            bookrow.appendChild(converImageHD);
            bookrow.appendChild(quantityHD);
            bookrow.appendChild(totalPriceHD);
            bookrow.appendChild(deleteHD);

            shoppingCartTable.appendChild(bookrow);

            //write the new table
            booksToBuy.forEach((book) => {

                var bookrow = document.createElement("tr");
                var titleTD = document.createElement("td");
                titleTD.innerHTML = book["title"];
                var authorTD = document.createElement("td");
                authorTD.innerHTML = book["author"];
                var coverImageTD = document.createElement("td");
                coverImageTD.innerHTML = "<img class='img-fluid' src=" + book["coverImage"] + "> ";
                var quantityTD = document.createElement("td");
                quantityTD.innerHTML = "<input style='width:50px;' type='number'value =" + book["quantity"] + " id=quantitySc" + book['id'] +
                    " onchange=updateBasketQuantity(this) >";
                var totalPriceTD = document.createElement("td");
                totalPriceTD.innerHTML = book["price"] * book["quantity"];
                var deleteButton = document.createElement("td");
                deleteButton.innerHTML = '<button onclick=deleteFromBasket(' + book['id'] + ') class="btn btn-danger btn-sm rounded-0" type="button"><i class="fa fa-trash-o" style="font-size:32px;color:red"></i></button>';
                bookrow.appendChild(titleTD);
                bookrow.appendChild(authorTD);
                bookrow.appendChild(coverImageTD);
                bookrow.appendChild(quantityTD);
                bookrow.appendChild(totalPriceTD);
                bookrow.appendChild(deleteButton);

                shoppingCartTable.appendChild(bookrow);
                //Add event listener on change of quantity

            })
        }
        ).catch(error => {
            throw (error);
        })
};