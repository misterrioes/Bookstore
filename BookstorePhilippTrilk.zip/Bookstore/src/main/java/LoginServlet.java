import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class LoginServlet
 */
@WebServlet("/LoginServlet")
public class LoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		// get request parameters for userID and password
		String user = request.getParameter("user");
		String pwd = request.getParameter("pwd");
		Integer userId = null;
		PreparedStatement pstmt= null;
		HttpSession session = request.getSession(true);
		Connection mariaDb = null;
		ResultSet sqlResult = null;

		try {
			Class.forName("org.mariadb.jdbc.Driver");
		} catch (ClassNotFoundException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}

		try {

			mariaDb = JDBCConnection.getMariaDbConnection();

			pstmt = mariaDb
					.prepareStatement("Select * from users where username = ? and password = ?");
			pstmt.setString(1, user);
			pstmt.setString(2, pwd);
			sqlResult = pstmt.executeQuery();
			sqlResult.next();
			userId = sqlResult.getInt("userId");
		}
		catch (SQLException e) {
			e.printStackTrace();
		}	
		
		finally  {
				if (sqlResult != null) {
					try {
						sqlResult.close();
					} catch (SQLException e) {
						e.printStackTrace();
					}
				}
				if (pstmt != null) {
					try {
						pstmt.close();
					} catch (SQLException e) {
						e.printStackTrace();
					}
				}
				if (mariaDb != null) {
					try {
						mariaDb.close();
					} catch (SQLException e) {
						e.printStackTrace();
					}
				}
			}
			if (userId != null && userId != 0) {
			session.setAttribute("username", user);
			session.setAttribute("userId", userId);
			session.setMaxInactiveInterval(30 * 60);
			// setting cookie to expiry in 30 mins
			response.sendRedirect("/Bookstore/LoginSucess.jsp");
		} else {
			RequestDispatcher rd = getServletContext().getRequestDispatcher("/LoginPage.jsp");
			PrintWriter out = response.getWriter();
			out.println("<font color=red>Either user name or password is" + user + pwd + " wrong.</font> ");
			rd.include(request, response);
		}
		}
	}
