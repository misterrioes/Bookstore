import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@WebServlet("/RegisterServlet")
public class RegisterServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;


    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String username = request.getParameter("regUser");
        String password = request.getParameter("regPwd");
        try {
            // Establish a connection to the MariaDB database
            Connection connection = JDBCConnection.getMariaDbConnection();

            // Prepare the SQL statement to insert the username and password into the database
            String sql = "INSERT INTO users (username, password) VALUES (?, ?)";
            PreparedStatement statement = connection.prepareStatement(sql);
            statement.setString(1, username);
            statement.setString(2, password);

            // Execute the SQL statement
            int rowsInserted = statement.executeUpdate();

            // Close the database resources
            statement.close();
            connection.close();

            if (rowsInserted > 0) {

    			response.sendRedirect("/Bookstore/LoginPage.jsp");

            } else {
                // Registration failed
                response.getWriter().println("Registration failed!");
            }
        } catch (SQLException e) {
            // Handle any exceptions that occurred during the database operation
            e.printStackTrace();
            response.getWriter().println("An error occurred while processing your request.");
        }
    }
}