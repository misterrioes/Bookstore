
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.google.gson.Gson;

import myownpkg.Book;

/**
 * Servlet implementation class ShoppingCartServlet
 */
@WebServlet("/ShoppingCartServlet")
public class ShoppingCartServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public ShoppingCartServlet() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		PreparedStatement pstmt = null;
		HttpSession session = request.getSession(true);
		Connection mariaDb = null;
		Integer userId = (Integer) session.getAttribute("userId");
		ResultSet rSet = null;
		ArrayList<Book> books = new ArrayList<>();
		String booksJson = null;
		Book book = null;

		if (userId != null) {
			try {
				Class.forName("org.mariadb.jdbc.Driver");
			} catch (ClassNotFoundException e1) {
				e1.printStackTrace();
			}

			try {

				mariaDb = JDBCConnection.getMariaDbConnection();
				pstmt = mariaDb
						.prepareStatement("SELECT b.*, sc.quantity AS quantitySc\r\n" + "FROM shopping_cart sc\r\n"
								+ "JOIN books b ON sc.book_id = b.id\r\n" + "WHERE sc.user_id = ?;");
				pstmt.setInt(1, userId);

				rSet = pstmt.executeQuery();
				
				while (rSet.next()) {
					int id = rSet.getInt("id");
					String title = rSet.getString("title");
					String author = rSet.getString("author");
					String coverImage = rSet.getString("cover_image");
					double price = rSet.getDouble("price");
					String description = rSet.getString("description");
					int quantity = rSet.getInt("quantitySc");
					book = new Book(id, title, author, coverImage, price, description, quantity);
					books.add(book);
				}
			}

			catch (SQLException e) {
				e.printStackTrace();
			}
			booksJson = new Gson().toJson(books);
			PrintWriter out = response.getWriter();
			response.setContentType("application/json");
			response.setCharacterEncoding("UTF-8");
			out.print(booksJson);
			out.flush();
		} else {
			response.setStatus(HttpServletResponse.SC_BAD_REQUEST);
			PrintWriter out = response.getWriter();
			out.print("You are not logged in");
			out.flush();
		}

	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub));
		PreparedStatement pstmt = null;
		HttpSession session = request.getSession(true);
		Connection mariaDb = null;
		Integer userId = (Integer) session.getAttribute("userId");
		ResultSet rSet = null;
		String action = request.getParameter("action");
		Integer bookId = null;
		Integer quantityToBuy = 0;

		try {
			mariaDb = JDBCConnection.getMariaDbConnection();

			if (action.equals("deleteFromBasket")) {
				bookId = Integer.parseInt(request.getParameter("bookId"));
				pstmt = mariaDb
						.prepareStatement("Delete From shopping_cart where book_id = ? and user_id = ?");
				pstmt.setInt(1, bookId);
				pstmt.setInt(2, userId);
				pstmt.executeUpdate();
				pstmt.close();
			}
			
			if (action.equals("updateBasket")) {
				bookId = Integer.parseInt(request.getParameter("bookId"));

				if (request.getParameter("quantity") != "") {
					quantityToBuy = Integer.parseInt(request.getParameter("quantity"));
				}

				// update the new quantity to buy
				pstmt = mariaDb
						.prepareStatement("UPDATE shopping_cart set quantity= ? where book_id = ? and user_id = ?");
				pstmt.setInt(1, quantityToBuy);
				pstmt.setInt(2, bookId);
				pstmt.setInt(3, userId);
				pstmt.executeUpdate();
				pstmt.close();
			}

			// handles to add book to the shopping Cart updates the database
			if (action.equals("putToBasket")) {
				bookId = Integer.parseInt(request.getParameter("bookId"));
				quantityToBuy = Integer.parseInt(request.getParameter("quantity"));
				// check if the book was already bought by the user
				pstmt = mariaDb
						.prepareStatement("Select sc.* from shopping_cart sc where sc.book_id = ? and sc.user_id = ?");
				pstmt.setInt(1, bookId);
				pstmt.setInt(2, userId);
				rSet = pstmt.executeQuery();
				
				Integer newQuantity = quantityToBuy;
				if (rSet.next()) {
					newQuantity = rSet.getInt("quantity") + quantityToBuy;
					pstmt = mariaDb.prepareStatement(
							"UPDATE shopping_cart Set quantity = ? where book_id = ? and user_id = ?");
					pstmt.setInt(1, newQuantity);
					pstmt.setInt(2, bookId);
					pstmt.setInt(3, userId);
					pstmt.executeUpdate();
					pstmt.close();
				} else {

					System.out.println("Put to basket new Book with BoookId: " + bookId + "userdId = " + userId
							+ "quantity= " + newQuantity);
					pstmt = mariaDb.prepareStatement("INSERT INTO shopping_cart  VALUES (?, ?, ? );");

					pstmt.setInt(1, userId);
					pstmt.setInt(2, bookId);
					pstmt.setInt(3, newQuantity);
					pstmt.executeUpdate();
					pstmt.close();
				}

			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {

			if (rSet != null) {
				try {
					rSet.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
			if (pstmt != null) {
				try {
					pstmt.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
			if (mariaDb != null) {
				try {
					mariaDb.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}

	}


}
