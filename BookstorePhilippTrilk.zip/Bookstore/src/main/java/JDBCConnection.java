
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;


public abstract class JDBCConnection {

	static String url = "jdbc:mariadb://localhost:3306/bookstore";
	static String userdb = "root";
	static String passworddb = "hallo21";
	Connection con = null;

	public static Connection getMariaDbConnection() throws SQLException {
		try {
			Class.forName("org.mariadb.jdbc.Driver");
		} catch (ClassNotFoundException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		return DriverManager.getConnection(url, userdb, passworddb);
	}
}


