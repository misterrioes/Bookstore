
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import myownpkg.Book;

/**
 * Servlet implementation class BookDetailPageServlet
 */
@WebServlet("/BookDetailPageServlet")
public class BookDetailPageServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public BookDetailPageServlet() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		Connection mariaDb = null;
		Book book = null;
		ResultSet rs = null;
		PreparedStatement pstmt = null;

		try {
			mariaDb = JDBCConnection.getMariaDbConnection();
			pstmt = mariaDb.prepareStatement("Select * from books where id= ?");
			pstmt.setString(1, request.getParameter("bookID"));
			rs = pstmt.executeQuery();
			rs.next();
			int id = rs.getInt("id");
			String title = rs.getString("title");
			String author = rs.getString("author");
			String coverImage = rs.getString("cover_image");
			double price = rs.getDouble("price");
			String description = rs.getString("description");
			int quantity = rs.getInt("quantity");
			book = new Book(id, title, author, coverImage, price, description, quantity);
		}

		catch (SQLException e) {
			e.printStackTrace();
		}
		// Close the database resources
		finally {
			if (rs != null) {
				try {
					rs.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
			if (pstmt != null) {
				try {
					pstmt.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
			if (mariaDb != null) {
				try {
					mariaDb.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}
		request.setAttribute("bookToDisplay", book);
		request.getRequestDispatcher("/BookDetailpage.jsp").forward(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
