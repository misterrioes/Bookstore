import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.google.gson.Gson;

import myownpkg.Book;

/**
 * Servlet implementation class BookListServlet
 */
@WebServlet("/BookListServlet")
public class BookListServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public BookListServlet() {
		super();
		// TODO Auto-generated constructor stub
	}

	public static void putIntoTabledataTags(Object obj, StringBuilder tableHtml) {
		tableHtml.append("<td>");
		tableHtml.append(obj.toString());
		tableHtml.append("</td>");
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		StringBuilder tableHtml = new StringBuilder();
		ArrayList<Book> books = new ArrayList<>();
		Connection mariaDb = null;
		ResultSet rs = null;
		PreparedStatement pstmt = null;

		try {
			mariaDb = JDBCConnection.getMariaDbConnection();
			pstmt = mariaDb.prepareStatement("Select * from books");
			rs = pstmt.executeQuery();
			while (rs.next()) {
				int id = rs.getInt("id");
				String title = rs.getString("title");
				String author = rs.getString("author");
				String coverImage = rs.getString("cover_image");
				double price = rs.getDouble("price");
				String description = rs.getString("description");
				int quantity = rs.getInt("quantity");
				Book book = new Book(id, title, author, coverImage, price, description, quantity);
				books.add(book);
			}
		}

		catch (SQLException e) {
			e.printStackTrace();
		}
		// Close the database resources
		finally {
			if (rs != null) {
				try {
					rs.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
			if (pstmt != null) {
				try {
					pstmt.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
			if (mariaDb != null) {
				try {
					mariaDb.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}

		// Write the books into the HTML table
		tableHtml.append("<tr>");
		tableHtml.append("<th scope=\"col\">Title</th>");
		tableHtml.append("<th scope=\"col\">Cover Image</th>");
		tableHtml.append("<th scope=\"col\">Author</th>");
		tableHtml.append("<th scope=\"col\">Price</th>");
		tableHtml.append("</tr>");

		for (Book book : books) {
			tableHtml.append("<tr>");
			tableHtml.append("<td> <a href=BookDetailPageServlet?bookID=").append(book.getId()).append(">")
					.append(book.getTitle()).append("</a> </td>");

			tableHtml.append("<td> <a href=BookDetailPageServlet?bookID=").append(book.getId()).append(">")
					.append("<img class='img-fluid' src='").append(book.getCoverImage()).append("'> </a> </img> </td>");

			tableHtml.append("<td>").append(book.getAuthor()).append("</td>");
			tableHtml.append("<td>").append(book.getPrice()).append("</td>");
			tableHtml.append("</tr>");
		}

		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		out.println(tableHtml.toString());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		Connection mariaDb = null;
		ResultSet rs = null;
		PreparedStatement pstmt = null;
		String searchString = request.getParameter("searchWords");
		Book book = null;
		ArrayList<Book> books = new ArrayList<>();
		String booksJson = null;
		
		try {
			mariaDb = JDBCConnection.getMariaDbConnection();
			pstmt = mariaDb.prepareStatement("Select * from books where ISBN like ? or title like ? or author like ?");
			pstmt.setString(1, "%"+searchString+"%");
			pstmt.setString(2, "%"+searchString+"%");
			pstmt.setString(3, "%"+searchString+"%");
			rs = pstmt.executeQuery();
			while (rs.next()) {
				int id = rs.getInt("id");
				String title = rs.getString("title");
				String author = rs.getString("author");
				String coverImage = rs.getString("cover_image");
				double price = rs.getDouble("price");
				String description = rs.getString("description");
				int quantity = rs.getInt("quantity");
				book = new Book(id, title, author, coverImage, price, description, quantity);
				books.add(book);
			}
		}

		catch (SQLException e) {
			e.printStackTrace();
		}
		// Close the database resources
		finally {
			if (rs != null) {
				try {
					rs.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
			if (pstmt != null) {
				try {
					pstmt.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
			if (mariaDb != null) {
				try {
					mariaDb.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}
		booksJson = new Gson().toJson(books);
		PrintWriter out = response.getWriter();
		response.setContentType("application/json");
		response.setCharacterEncoding("UTF-8");
		out.print(booksJson);
		out.flush();

	}
}
