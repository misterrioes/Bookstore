package myownpkg;

	public class Book {
	    private int id;
	    private String title;
	    private String author;
	    private String coverImage;
	    private double price;
	    private String description;
	    private int quantity;

	    // Constructor without parameters (default constructor)
	    public Book() {
	    }

	    // Constructor with parameters
	    public Book(int id, String title, String author, String coverImage, double price, String description, int quantity) {
	        this.id = id;
	        this.title = title;
	        this.author = author;
	        this.coverImage = coverImage;
	        this.price = price;
	        this.description = description;
	        this.quantity = quantity;
	    }
	    // Getter and Setter for id
	    public int getId() {
	        return id;
	    }

	    public void setId(int id) {
	        this.id = id;
	    }

	    // Getter and Setter for title
	    public String getTitle() {
	        return title;
	    }

	    public void setTitle(String title) {
	        this.title = title;
	    }

	    // Getter and Setter for author
	    public String getAuthor() {
	        return author;
	    }

	    public void setAuthor(String author) {
	        this.author = author;
	    }

	    // Getter and Setter for coverImage
	    public String getCoverImage() {
	        return coverImage;
	    }

	    public void setCoverImage(String coverImage) {
	        this.coverImage = coverImage;
	    }

	    // Getter and Setter for price
	    public double getPrice() {
	        return price;
	    }

	    public void setPrice(double price) {
	        this.price = price;
	    }

	    // Getter and Setter for description
	    public String getDescription() {
	        return description;
	    }

	    public void setDescription(String description) {
	        this.description = description;
	    }

	    // Getter and Setter for quantity
	    public int getQuantity() {
	        return quantity;
	    }

	    public void setQuantity(int quantity) {
	        this.quantity = quantity;
	    }
	}
